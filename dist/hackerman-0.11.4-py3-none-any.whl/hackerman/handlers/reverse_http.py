from flask import flask, request
from hackerman import utils
import json

class #CONT